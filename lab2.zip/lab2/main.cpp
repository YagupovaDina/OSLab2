#include <sys/stat.h>
#include <unistd.h>
#include <syslog.h>
#include <signal.h>
#include "disk_monitor.h"

int main() {
  openlog("disk monitor", LOG_PID | LOG_CONS, LOG_USER);

  char dir[PATH_MAX];
  getcwd(dir, PATH_MAX);
  DiskMonitor::s_configFile = strcat(dir, "/diskmonitor.conf");

  pid_t pid = fork();
  if (pid < 0) {
    syslog(LOG_ERR, "fork failed");
    exit(EXIT_FAILURE);
  }
  if (pid > 0) {
    syslog(LOG_INFO, "forked succesfully");
    exit(EXIT_SUCCESS);
  }

  DiskMonitor::changePidFile();

  umask(0);
  if (setsid() < 0) {
    syslog(LOG_ERR, "session creation failed");
    exit(EXIT_FAILURE);
  }
  syslog(LOG_INFO, "created session succesfully");

  if (chdir("/") < 0) {
    syslog(LOG_ERR, "working directory change failed");
    exit(EXIT_FAILURE);
  }
  close(STDIN_FILENO);
  close(STDOUT_FILENO);
  close(STDERR_FILENO);
  struct sigaction act;
  memset(&act, 0, sizeof(act));
  act.sa_handler = &DiskMonitor::signalsHandler;
  sigset_t set;
  sigemptyset(&set);
  sigaddset(&set, SIGHUP);
  sigaddset(&set, SIGTERM);
  act.sa_mask = set;
  sigaction(SIGHUP, &act, 0);
  sigaction(SIGTERM, &act, 0);
  syslog(LOG_INFO, "daemon is running");

  DiskMonitor::readConfig();
  DiskMonitor::runDaemon();
  return EXIT_SUCCESS;
}

