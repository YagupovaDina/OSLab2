#include "disk_monitor.h"

int DiskMonitor::s_fd = -1;
std::vector<std::string> DiskMonitor::s_folders;
std::string DiskMonitor::s_configFile;

void DiskMonitor::changePidFile() {
  std::ifstream pidFileRead;
  std::ofstream pidFileWrite;
  pidFileRead.open(PID_FILE);
  syslog(LOG_INFO, "change pid file");
  if (pidFileRead.is_open()) {
    int oldPid;
    pidFileRead >> oldPid;
    syslog(LOG_INFO, "killing old daemon process %d", oldPid);
    kill(oldPid, SIGTERM);
    pidFileWrite.open(PID_FILE, std::ios::out | std::ios::trunc);
    if (!pidFileWrite.is_open()) {
      syslog(LOG_ERR, "can't write to pidfile");
      exit(EXIT_FAILURE);
    }
    pidFileWrite << getpid() << std::endl;
    pidFileRead.close();
  } else {
    syslog(LOG_ERR, "create and write");
    pidFileWrite.open(PID_FILE);
    if (!pidFileWrite.is_open()) {
      syslog(LOG_ERR, "can't write to pidfile");
      exit(EXIT_FAILURE);
    }
    pidFileWrite << getpid() << std::endl;
  }
  pidFileWrite.close();
}

void DiskMonitor::signalsHandler(int signum) {
  syslog(LOG_INFO, "signal");
  switch(signum) {
  case SIGHUP:
    DiskMonitor::readConfig();
    break;
  case SIGTERM:
    unlink(PID_FILE);
    syslog(LOG_INFO, "exit daemon");
    closelog();
    close(s_fd);
    exit(EXIT_SUCCESS);
    break;
  }
}

void DiskMonitor::_handleEvent(inotify_event* event) {
  if (event->mask & IN_ISDIR) {
    return;
  }

  char* filename;
  std::string nameWPath;
  if (event->len) {
    filename = event->name;
    nameWPath = s_folders.at(event->wd - 1) + "/" + std::string(filename);
  }
  switch(event->mask & (IN_ALL_EVENTS | IN_Q_OVERFLOW | IN_UNMOUNT | IN_IGNORED)) {
  case IN_OPEN:
    syslog(LOG_INFO | LOG_LOCAL0, "open: \"%s\"", nameWPath.c_str());
    break;
  case IN_ACCESS:
    syslog(LOG_INFO | LOG_LOCAL0, "access: \"%s\"", nameWPath.c_str());
    break;
  case IN_MODIFY:
    syslog(LOG_INFO | LOG_LOCAL0, "modify: \"%s\"", nameWPath.c_str());
    break;
  case IN_ATTRIB:
    syslog(LOG_INFO | LOG_LOCAL0, "attrib: \"%s\"", nameWPath.c_str());
    break;
  case IN_CLOSE_WRITE:
    syslog(LOG_INFO | LOG_LOCAL0, "close_write: \"%s\"", nameWPath.c_str());
    break;
  case IN_CLOSE_NOWRITE:
    syslog(LOG_INFO | LOG_LOCAL0, "close_nowrite: \"%s\"", nameWPath.c_str());
    break;
  case IN_MOVED_TO:
    syslog(LOG_INFO | LOG_LOCAL0, "moved_to: \"%s\", cookie=%d", nameWPath.c_str(), event->cookie);
    break;
  case IN_MOVED_FROM:
    syslog(LOG_INFO | LOG_LOCAL0, "moved_from: \"%s\", cookie=%d", nameWPath.c_str(), event->cookie);
    break;
  case IN_CREATE:
    syslog(LOG_INFO | LOG_LOCAL0, "create: \"%s\"", nameWPath.c_str());
    break;
  case IN_DELETE:
    syslog(LOG_INFO | LOG_LOCAL0, "delete: \"%s\"", nameWPath.c_str());
    break;
  case IN_DELETE_SELF:
    syslog(LOG_INFO | LOG_LOCAL0, "delete_self: \"%s\"", nameWPath.c_str());
    break;
  case IN_MOVE_SELF:
    syslog(LOG_INFO | LOG_LOCAL0, "move_self: \"%s\"", nameWPath.c_str());
    break;
  case IN_UNMOUNT:
    syslog(LOG_INFO | LOG_LOCAL0, "unmount: \"%s\"", nameWPath.c_str());
    break;
  case IN_Q_OVERFLOW:
    syslog(LOG_INFO | LOG_LOCAL0, "event queue overflowed");
    break;
  case IN_IGNORED:
    syslog(LOG_INFO | LOG_LOCAL0, "watch %d was removed", event->wd);;
    break;
  default:
    syslog(LOG_INFO | LOG_LOCAL0, "unknown event: \"%s\"", nameWPath.c_str());
    break;
  }
}

void DiskMonitor::_readEvents(std::queue<inotify_event*>& events) {
  int availSize;
  ioctl(s_fd, FIONREAD, &availSize);
  char buffer[availSize];
  read(s_fd, buffer, availSize);
  int offset = 0;
  while (offset < availSize) {
    inotify_event* event = (inotify_event*)(buffer + offset);
    inotify_event* qElem = (inotify_event*)malloc(sizeof(inotify_event) + event->len);
    memmove(qElem, event, sizeof(inotify_event) + event->len);
    events.push(qElem);
    offset += sizeof(inotify_event) + event->len;
  }
}

void DiskMonitor::runDaemon() {
  std::queue<inotify_event*> events;
  while(true) {
    if (s_fd < 0) {
      return;
    }
    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(s_fd, &rfds);
    if (select(FD_SETSIZE, &rfds, NULL, NULL, NULL) <= 0) {
      continue;
    }

    _readEvents(events);

    int len = events.size();
    for (int i = 0; i < len; i++) {
      _handleEvent(events.back());
      free(events.back());
      events.pop();
    }
  }
}

void DiskMonitor::readConfig() {
  syslog(LOG_INFO, "reread config");

  close(s_fd);
  s_folders.clear();
  s_fd = inotify_init();
  if (s_fd < 0) {
    syslog(LOG_ERR, "can't init inotify");
    return;
  }

  std::ifstream file;
  syslog(LOG_INFO, "%s", s_configFile.c_str());
  file.open(s_configFile.c_str());
  std::string str;
  int wd = 0;
  while(std::getline(file, str)) {
    wd = inotify_add_watch(s_fd, str.c_str(), IN_ALL_EVENTS);
    if (wd < 0) {
      syslog(LOG_ERR, "can't add watch item %s", str.c_str());
    } else {
      syslog(LOG_INFO, "watching item %s", str.c_str());
      s_folders.push_back(str);
    }
  }
  file.close();
}

