#!/bin/bash
# DO NOT MODIFY THIS FILE!
cd "$(dirname "$0")"
res=0
g++ -Wall -Werror main.cpp disk_monitor.cpp disk_monitor.h -o main.out
if [ "$?" -ne "0" ]; then
  res=1
fi

exit $res
