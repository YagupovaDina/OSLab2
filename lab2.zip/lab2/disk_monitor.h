#ifndef DISK_MONITOR_H
#define DISK_MONITOR_H

#include <stdio.h>
#include <signal.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/inotify.h>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <sys/ioctl.h>
#include <cstring>
#include <linux/limits.h>

class DiskMonitor {
public:
  static void changePidFile();
  static void signalsHandler(int signum);
  static void runDaemon();
  static void readConfig();
  static std::string s_configFile;
private:
  static void _readEvents(std::queue<inotify_event*>& events);
  static void _handleEvent(inotify_event* event);
  static int s_fd;
  static std::vector<std::string> s_folders;
};

#define PID_FILE "/var/run/diskmonitor.pid"

#endif //DISK_MONITOR

